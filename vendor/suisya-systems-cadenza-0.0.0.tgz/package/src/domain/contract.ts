/**
 * The delegation contract as a value, and the refusals that stand between a
 * caller and an invalid one.
 *
 * `docs/design/g2-delegation-contract.md` sections 4 and 5, against DECISIONS.md
 * D-0026 and D-0027.
 *
 * The load-bearing property of this module is negative: **there is no route to
 * an invalid contract**. `delegationContract` validates every rule before it
 * returns, and nothing else constructs one, so "classifying against an invalid
 * contract is refused" (D-0026 section 3) needs no branch in the classifier --
 * it cannot be handed one. That is why the type is an interface with a factory
 * rather than a class with public fields, and why the factory validates its
 * inputs at runtime even where the types already say `string`: a JavaScript
 * caller, or a cast, reaches past the types, and the contract is a persisted,
 * digested value (D-0015).
 */

import {
  canonicalCapabilityKeys,
  refuseCapabilityOverlap,
  requireKnownVocabularyVersion,
  vocabularyFor,
} from "./capability.js";
import { DIGEST_PATTERN } from "./digest.js";
import {
  ForgedContractError,
  InvalidDigestError,
  InvalidIdentifierError,
  InvalidIdentityError,
  SelfIssuedContractError,
} from "./errors.js";
import { parseIdentifier } from "./identifiers.js";
import {
  escapeNonAscii,
  isControlCharacter,
  isPythonSpace,
  pythonAscii,
  pythonTypeName,
} from "./python-text.js";

/** D-0026 section 1: opaque to cadenza, but not unbounded. Design document section 4.1. */
export const MAX_IDENTITY_LENGTH = 256;

/**
 * The type-level half of the mark {@link delegationContract} leaves.
 *
 * Without it `DelegationContract` is a structural type, so an object literal
 * with the right fields is one as far as the type checker is concerned -- and
 * "valid by construction" would be a claim the types actively fail to make.
 * The symbol is module-private, so no caller can name the property.
 *
 * It is **declared and never created**, so nothing carries it at runtime. An
 * earlier version made it a real symbol property, which review found copyable:
 * `{ ...contract, grantee: "forged" }` carries a symbol-keyed property across,
 * so a spread produced a value that passed the check while holding fields that
 * had been through no validation. Provenance that a copy can inherit is not
 * provenance. {@link ISSUED} is the half that survives a spread.
 */
declare const CONTRACT_BRAND: unique symbol;

/**
 * The contracts this process actually built.
 *
 * A `WeakSet` holds its members by identity and cannot be read, enumerated or
 * copied from a value: spreading a contract, cloning it, or building a literal
 * that looks exactly like one all produce an object this set does not contain.
 * It is weak so that holding a contract for the length of a run does not keep it
 * alive afterwards.
 */
const ISSUED = new WeakSet<object>();

/** A delegation contract, frozen and valid by construction. */
export interface DelegationContract {
  /** Set only by {@link delegationContract}; unreachable from outside this module. */
  readonly [CONTRACT_BRAND]: true;
  readonly vocabularyVersion: number;
  readonly projectId: string;
  readonly configDigest: string;
  readonly issuer: string;
  readonly grantee: string;
  /** Sorted by code point, unique, frozen. Order and repetition are not semantics. */
  readonly granted: readonly string[];
  /** Sorted by code point, unique, frozen, and disjoint from {@link granted}. */
  readonly askable: readonly string[];
  /** The `contract_digest` this replaces, or `null` when it opens a lineage. */
  readonly supersedes: string | null;
}

/** What a caller supplies. Every field is validated; none is defaulted. */
export interface DelegationContractInput {
  readonly vocabularyVersion: number;
  readonly projectId: string;
  readonly configDigest: string;
  readonly issuer: string;
  readonly grantee: string;
  readonly granted: readonly string[];
  readonly askable: readonly string[];
  readonly supersedes?: string | null;
}

/**
 * Build a contract, or refuse and name what was refused.
 *
 * The order of the checks is the order of the design document's section 5 table,
 * so a reader comparing the two does not have to hold a permutation in their
 * head. It is observable -- an input wrong in two ways reports the earlier rule
 * -- which is why it is fixed here rather than left to whichever check the
 * implementation happened to write first.
 */
export function delegationContract(input: DelegationContractInput): DelegationContract {
  const version = requireKnownVocabularyVersion(input.vocabularyVersion);
  const vocabulary = vocabularyFor(version) as ReadonlySet<string>;

  const granted = canonicalCapabilityKeys(input.granted, "granted", version, vocabulary);
  const askable = canonicalCapabilityKeys(input.askable, "askable", version, vocabulary);
  refuseCapabilityOverlap(granted, askable);

  const issuer = requireIdentity(input.issuer, "issuer");
  const grantee = requireIdentity(input.grantee, "grantee");
  if (issuer === grantee) {
    throw new SelfIssuedContractError(
      `issuer ${pythonAscii(issuer)} is its own grantee: a contract cannot be self-issued`,
    );
  }

  const projectId = requireProjectId(input.projectId);
  const configDigest = requireDigest(input.configDigest, "config_digest");
  const supersedes =
    input.supersedes === undefined || input.supersedes === null
      ? null
      : requireDigest(input.supersedes, "supersedes");

  const contract = Object.freeze({
    vocabularyVersion: version,
    projectId,
    configDigest,
    issuer,
    grantee,
    granted,
    askable,
    supersedes,
  }) as DelegationContract;
  ISSUED.add(contract);
  return contract;
}

/**
 * True only for a value {@link delegationContract} produced.
 *
 * The type-level half of the brand stops an object literal at compile time; this
 * is the half that survives a cast and a JavaScript caller. Anything that reads
 * a contract's semantics -- `contractDigest` today, the classifier next --
 * checks it, because a forged contract is exactly the invalid contract the
 * design document says cannot exist (section 4).
 */
export function isDelegationContract(value: unknown): value is DelegationContract {
  return typeof value === "object" && value !== null && ISSUED.has(value);
}

/** Refuse anything that did not come from {@link delegationContract}. */
export function requireContract(value: unknown): DelegationContract {
  if (!isDelegationContract(value)) {
    throw new ForgedContractError(
      "value was not produced by delegationContract(): a contract is recognised by " +
        "identity, and a copy of one has been through no validation",
    );
  }
  return value;
}

/**
 * Rules 1, 2 and 3 are `src/domain/capability.ts`'s.
 *
 * They moved there when the agent-type record (D-0034) needed the same three
 * rules over the same vocabulary; the sequence below is still this module's,
 * and `delegationContract()` is still the only place that runs all of it.
 */

/**
 * Rule 4. Opaque, but not unbounded (design document section 4.1).
 *
 * The lone-surrogate check is not taste. `contractDigest` encodes the identity
 * through `canonicalJsonBytes`, which throws `SurrogateInStringError` on an
 * unpaired surrogate (D-0013); an identity that passed validation and then made
 * the digest throw would be a contract that exists and cannot be classified,
 * since every classification carries the digest. It is refused here, where a
 * refusal is what the caller is expecting.
 */
function requireIdentity(value: unknown, field: string): string {
  if (typeof value !== "string") {
    throw new InvalidIdentityError(`${field} must be a string, got ${pythonTypeName(value)}`);
  }
  const length = Array.from(value).length;
  if (length === 0) {
    throw new InvalidIdentityError(`${field} must not be empty`);
  }
  if (length > MAX_IDENTITY_LENGTH) {
    throw new InvalidIdentityError(
      `${field} is ${length} characters, which is longer than the ${MAX_IDENTITY_LENGTH} allowed`,
    );
  }
  for (const character of value) {
    if (isControlCharacter(character)) {
      throw new InvalidIdentityError(`${field} ${pythonAscii(value)} contains a control character`);
    }
  }
  const first = Array.from(value)[0] as string;
  const last = Array.from(value)[length - 1] as string;
  if (isPythonSpace(first) || isPythonSpace(last)) {
    throw new InvalidIdentityError(
      `${field} ${pythonAscii(value)} has leading or trailing whitespace`,
    );
  }
  if (hasLoneSurrogate(value)) {
    throw new InvalidIdentityError(
      `${field} contains an unpaired surrogate, which cannot be encoded as UTF-8 ` +
        "and so could not be digested",
    );
  }
  return value;
}

/**
 * Rule 6, in ASCII.
 *
 * The rule itself is G1's and is reused unchanged (design document section 9);
 * what is added is the escaping. `parseIdentifier` formats the refused value
 * with `repr`, which keeps printable Unicode -- correct there, because the
 * ported suite pins those messages against CPython's -- and D-0007 requires
 * everything G2 prints to be ASCII. So the message is escaped rather than the
 * shared validator changed.
 */
function requireProjectId(value: unknown): string {
  try {
    return parseIdentifier(value, "project_id");
  } catch (error) {
    if (error instanceof InvalidIdentifierError) {
      throw new InvalidIdentifierError(escapeNonAscii(error.detail), error.location);
    }
    throw error;
  }
}

/** Rules 7 and 8. */
function requireDigest(value: unknown, field: string): string {
  if (typeof value !== "string") {
    throw new InvalidDigestError(`${field} must be a string, got ${pythonTypeName(value)}`);
  }
  if (!DIGEST_PATTERN.test(value)) {
    throw new InvalidDigestError(
      `${field} ${pythonAscii(value)} is not a digest: expected sha256: followed by ` +
        "64 lowercase hex digits",
    );
  }
  return value;
}

/** The same scan `canonicalJson` makes, asked as a question instead of a throw. */
function hasLoneSurrogate(value: string): boolean {
  for (let index = 0; index < value.length; index += 1) {
    const unit = value.charCodeAt(index);
    if (unit < 0xd800 || unit > 0xdfff) {
      continue;
    }
    const isHigh = unit <= 0xdbff;
    const next = index + 1 < value.length ? value.charCodeAt(index + 1) : Number.NaN;
    if (isHigh && next >= 0xdc00 && next <= 0xdfff) {
      index += 1;
      continue;
    }
    return true;
  }
  return false;
}
