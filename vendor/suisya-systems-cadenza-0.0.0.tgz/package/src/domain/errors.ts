/**
 * Typed refusals.
 *
 * Design doc section 7: no refusal is a bare `Error` and none is silent. Every
 * catalog-level failure carries where it happened, because the operator fixing
 * it is editing a file, not reading a stack trace.
 *
 * **The one shape change from Python, and why.** `CatalogError` in Python keeps
 * the bare text on `.message` and formats `"<message> (at <location>)"` in
 * `__str__`. `Error` in JavaScript has no `__str__`: `.message` *is* what a
 * matcher sees, and `expect(...).toThrow(/.../)` tests it the way pytest's
 * `match=` tests `str(exc)`. So `.message` here carries the **formatted** text,
 * and the bare text moves to `.detail`. Spelling it the other way round would
 * have made every `match=` translated from the Python suite silently stop
 * seeing the location.
 */

/** Base class for every error cadenza raises deliberately. */
export class CadenzaError extends Error {
  constructor(message: string) {
    super(message);
    // `new.target` rather than a literal per subclass: the name is the class's
    // own, so a subclass cannot forget to set it and report its parent's.
    this.name = new.target.name;
  }
}

/**
 * A catalog input was refused.
 *
 * `location` is either a file ("config/projects.toml") or a file and the key at
 * fault ("config/projects.toml: project.web.source.url").
 */
export class CatalogError extends CadenzaError {
  /** The refusal on its own, without the location. Python's `.message`. */
  readonly detail: string;
  readonly location: string | null;

  constructor(detail: string, location: string | null = null) {
    super(location === null ? detail : `${detail} (at ${location})`);
    this.detail = detail;
    this.location = location;
  }
}

/** `schema_version` is missing, not an integer, or unknown to this build. */
export class SchemaVersionError extends CatalogError {}

/** A key no table accepts. Tables are closed (design doc section 5.6). */
export class UnknownFieldError extends CatalogError {}

/** A required key is absent. */
export class MissingFieldError extends CatalogError {}

/** A project_id or alias does not match the identifier shape. */
export class InvalidIdentifierError extends CatalogError {}

/** A `[...source]` table is not a valid tagged union member. */
export class InvalidCloneSourceError extends CatalogError {}

/** `base_branch` is not a usable git ref name. */
export class InvalidBaseBranchError extends CatalogError {}

/** One name in the flat namespace maps to more than one project. */
export class NameCollisionError extends CatalogError {}

/** A tombstone carries extra fields or names a project no layer defines. */
export class TombstoneError extends CatalogError {}

/**
 * Resolution found no project for the given name.
 *
 * Not a `CatalogError`: the catalog is fine, the typed name is not.
 */
export class ProjectNotFoundError extends CadenzaError {}

/**
 * G2's refusals (`docs/design/g2-delegation-contract.md` section 9).
 *
 * They extend `CadenzaError` directly rather than `CatalogError`, because a
 * delegation contract is not a file in this belt: serialisation at the edge is
 * unfixed (D-0026 section 2), so there is no location to carry and a `location`
 * that was always `null` would be a field pretending to be evidence. What each
 * carries instead is what it refused -- the key, the version, the identity --
 * in the message, in ASCII (D-0007).
 *
 * `InvalidIdentifierError` above is reused unchanged for a contract's
 * `project_id`: it is the same shape from the same G1 rule, and a second error
 * type for it would say the shape had two meanings.
 */

/** A contract pinned a capability-vocabulary version this build does not know. */
export class UnknownVocabularyVersionError extends CadenzaError {}

/** A granted or askable key is not in the vocabulary version the contract pinned. */
export class UnknownCapabilityError extends CadenzaError {}

/** A key is both granted and askable, which would leave an action classifiable two ways. */
export class OverlappingCapabilityError extends CadenzaError {}

/** An issuer or grantee is absent or malformed. */
export class InvalidIdentityError extends CadenzaError {}

/** A contract's issuer is its own grantee. */
export class SelfIssuedContractError extends CadenzaError {}

/** A `sha256:<hex>` digest field is not one. */
export class InvalidDigestError extends CadenzaError {}

/** A value reached a contract-reading function without coming from `delegationContract`. */
export class ForgedContractError extends CadenzaError {}

/** A successor does not name the contract it replaces, or names one that is not current. */
export class SupersessionLineageError extends CadenzaError {}

/** A successor is for another run, or over another project, so it is not a successor. */
export class SupersessionSubjectError extends CadenzaError {}

/** A run tried to delegate without holding `delegation.issue`. */
export class UngrantedDelegationError extends CadenzaError {}

/** A sub-contract would carry more than the granter holds. */
export class AmplifiedGrantError extends CadenzaError {}

/**
 * The agent-type record's refusals (D-0034).
 *
 * `CadenzaError` directly, for the reason G2's do: the record is a value and
 * not a file in this belt -- D-0034 keeps the belt value-only and leaves the
 * store to its owner -- so there is no location to carry.
 *
 * Only two are new. Everything the record shares with a contract reuses the
 * contract's refusal rather than gaining a parallel one: the vocabulary
 * version, the capability keys, the disjointness of the two sets and the
 * identifier shape are the same rules over the same vocabulary, and a second
 * error type for each would say the rule had two meanings.
 */

/** A `loopPolicy` or `executorPolicy` member is absent, ill-typed, out of range, or unknown. */
export class InvalidPolicyError extends CadenzaError {}

/** A value reached a record-reading function without coming from `agentType`. */
export class ForgedAgentTypeError extends CadenzaError {}

/**
 * The human-decision record's refusals (D-0036).
 *
 * `CadenzaError` directly, for the reason G2's do: a decision record is a value
 * this belt carries and never a file -- cadenza persists nothing (D-0026
 * section 2) -- so there is no location to carry and a `location` that was
 * always `null` would be a field pretending to be evidence.
 *
 * Only three are new. The two digest fields and the two identity fields reuse
 * `InvalidDigestError` and `InvalidIdentityError` rather than gaining parallel
 * types: they are the same rules over the same shapes, and a second error type
 * for each would say the rule had two meanings.
 */

/** `outcome` is not a member of the closed union. */
export class InvalidOutcomeError extends CadenzaError {}

/**
 * A decision that records a denial was offered as authority to issue.
 *
 * Distinct from {@link InvalidOutcomeError}: the record is well formed and the
 * human's answer was "no". Spending it as an approval is the one silent error
 * the enum exists to stop.
 */
export class UnapprovedDecisionError extends CadenzaError {}

/**
 * The successor issued is not the successor the decision names.
 *
 * The predecessor disagrees with the contract the run holds, the successor's
 * digest is not the one approved, or the surface on the contract is not the
 * surface on the decision.
 */
export class DecisionMismatchError extends CadenzaError {}

/**
 * The local-path verifier's refusals (D-0038, design doc section 3.1).
 *
 * `CadenzaError` directly rather than `CatalogError`, and the reason is the one
 * D-0036's family gives, arriving from the other side. A `CatalogError` carries
 * a `location` because an operator fixes it by editing a named key in a named
 * file. The verifier is handed a `LocalPathSource` -- a value that has already
 * left the file it came from, with no key and no origin attached -- so a
 * `location` here would be `null` on every instance: a field pretending to be
 * evidence. What each refusal carries instead is the path, the roots, and the
 * reason, in ASCII (D-0007).
 *
 * **Five types rather than one**, which is the opposite of what D-0036 chose for
 * the decision record, and the difference is what a caller does next. There, a
 * malformed digest and a malformed identity are both "the value you built is not
 * a record" and lead to the same place. Here each type is a different action by
 * a different person: a missing path is a stale catalog entry, a non-directory
 * is the wrong path, an unreadable one is a permissions problem on the
 * operator's machine, an escape is a refusal that must be reported as such and
 * never retried, and an unusable root is a misconfigured *layer* rather than a
 * misconfigured project. Collapsing them would make a caller parse a message to
 * tell a refusal from an accident -- and treating an escape as an accident, or
 * an accident as an escape, is exactly the confusion this belt exists to
 * prevent.
 */

/** Base of the verifier's family, so a caller may catch all five at once. */
export class LocalPathVerificationError extends CadenzaError {}

/** Nothing exists at the path, or a symlink on the way to it dangles. */
export class LocalPathMissingError extends LocalPathVerificationError {}

/** Something exists at the path, and it is not a directory to clone from. */
export class LocalPathNotADirectoryError extends LocalPathVerificationError {}

/**
 * The path could not be examined: permissions, or a symlink loop.
 *
 * Deliberately not folded into {@link LocalPathMissingError}. Reporting "does
 * not exist" for a path that exists and cannot be read sends an operator
 * looking for a stale catalog entry when what they have is a mode bit, and the
 * two fixes have nothing in common.
 */
export class LocalPathUnreadableError extends LocalPathVerificationError {}

/**
 * The path is not inside any allowed root of the layer that declared it.
 *
 * The refusal design doc section 3.1 calls mandatory. Raised in two situations
 * that the message distinguishes and the type does not: a path that climbs out
 * lexically, and a path that is lexically contained but whose links resolve
 * outside. Both are one answer -- this path is not in the roots you allowed --
 * and a caller that treated the second as milder would be defeating the check.
 */
export class LocalPathEscapesRootError extends LocalPathVerificationError {}

/**
 * An allowed root itself could not be established.
 *
 * Fails closed, and that is the decision rather than an accident of ordering: a
 * root that is absent, not a directory, or impossible to descend into cannot
 * contain anything, and skipping it would silently narrow the roots a layer
 * declared. "Descend into" and not "read": a root exists to be traversed, so
 * execute is required and read is not, and a mode-711 root is usable. Narrowing
 * them silently is how a verifier starts refusing paths that are configured
 * correctly, with the real fault -- an unmounted disk, a typo in
 * `allowed_local_roots` -- never named.
 */
export class AllowedRootUnusableError extends LocalPathVerificationError {}
